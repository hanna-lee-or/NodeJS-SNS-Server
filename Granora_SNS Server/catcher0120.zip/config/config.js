/**
 * 설정 파일
 *
 * @date 2019-11-13
 * @author Hanna
 */

module.exports = {
	server_port: 3000,
	//db_url: 'mongodb://localhost:27017/local',
	db_url: 'mongodb+srv://granora:gragra2020@testcluster-046lp.mongodb.net/test?retryWrites=true&w=majority',
	db_schemas: [
		{file:'./user_schema', collection:'users', schemaName:'UserSchema', modelName:'UserModel'},
		{file:'./post_schema', collection:'posts', schemaName:'PostSchema', modelName:'PostModel'},
		{file:'./userTrace_schema', collection:'userTraces', schemaName:'UserTraceSchema', modelName:'UserTraceModel'},
		{file:'./upment_schema', collection:'upments', schemaName:'UpmentSchema', modelName:'UpmentModel'},
		{file:'./downment_schema', collection:'downments', schemaName:'DownmentSchema', modelName:'DownmentModel'},
		{file:'./likePost_schema', collection:'likePosts', schemaName:'LikePostSchema', modelName:'LikePostModel'},
		{file:'./likeUpment_schema', collection:'likeUpments', schemaName:'LikeUpmentSchema', modelName:'LikeUpmentModel'},
		{file:'./likeDownment_schema', collection:'likeDownments', schemaName:'LikeDownmentSchema', modelName:'LikeDownmentModel'},
		{file:'./userFollow_schema', collection:'userFollows', schemaName:'UserFollowSchema', modelName:'UserFollowModel'},
		{file:'./removedPost_schema', collection:'removedPosts', schemaName:'RemovedPostSchema', modelName:'RemovedPostModel'},
		{file:'./clipPost_schema', collection:'clipPosts', schemaName:'ClipPostSchema', modelName:'ClipPostModel'},
		{file:'./studioHome_schema', collection:'studioHomes', schemaName:'StudioHomeSchema', modelName:'StudioHomeModel'},
	],
	route_info: [
        //{file:'./user', path:'/process/modifyUser', method:'modifyUser', type:'post'}
	],
	cloudinary: {
		cloud_name: 'dpzastavk',
		api_key: '932149863422966',
		api_secret: '6tpCID93NMx5MmuBl_4VRLnEdjg'	
	},
	twitter: {		// passport twitter
		clientID: 'ENzDjC22fL3zqRWFElADEzcLG',
		clientSecret: 'wi5n9NYdEKRS2wvBXl8DJ3J35CvkRDoElpnR0Vgad2yVKEjzkg',
		callbackURL: '/auth/twitter/callback'
	},
	google: {		// passport google
		clientID: '402719781703-1hi8r2742tequag0qtu1cd4v597ln5vq.apps.googleusercontent.com',
		clientSecret: 'xNcHRsY5iCi1ZRPt9Y4FUqHk',
		callbackURL: '/auth/google/callback'
	},
	naver: {
		clientID : '3Q18FnELEcaoJOevUJ2q',
		clientSecret : 'UXpXtuSCdU',
		callbackURL : '/auth/naver/callback'
	  }
	// facebook: {		// passport facebook
	// 	clientID: '1442860336022433',
	// 	clientSecret: '13a40d84eb35f9f071b8f09de10ee734',
	// 	callbackURL: 'http://localhost:3000/auth/facebook/callback'
	// },
}